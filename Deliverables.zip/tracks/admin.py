from django.contrib import admin
from .models import Track
# Register your models here.
admin.site.register(Track)
