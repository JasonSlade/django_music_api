# DATABASE (rows)
#   ↓
# BACKEND (objects)
#   ↓ res.json()
# JSON (text)
#   ↓ response.json()
# FRONTEND (JS object)